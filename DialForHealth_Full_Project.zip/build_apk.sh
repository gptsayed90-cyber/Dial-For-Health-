#!/data/data/com.termux/files/usr/bin/bash
set -e
export JAVA_HOME="${JAVA_HOME:-$PREFIX/lib/jvm/java-17-openjdk}"
export ANDROID_HOME="${ANDROID_HOME:-$HOME/android-sdk}"
gradle clean assembleDebug
echo "APK: $PWD/app/build/outputs/apk/debug/app-debug.apk"
