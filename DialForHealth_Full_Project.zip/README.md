# Dial For Health (নোয়াখালী) — Full Android Project

একটি পূর্ণ starter Android project।

## Features
- Medical Home Page
- Doctor Appointment
- Hospital Search
- Lab Test
- Medicine Order
- Ambulance
- Health Tips
- Medical Records
- Login + OTP UI
- Registration
- Forgot Password UI
- Employee Location UI
- GPS permission declarations

## Termux
1. ZIP Download folder-এ রাখুন।
2. `termux-setup-storage`
3. `cd ~/storage/downloads`
4. `unzip DialForHealth_Full_Project.zip`
5. `cd DialForHealth_Full_Project`
6. `chmod +x build_apk.sh`
7. `./build_apk.sh`

APK: `app/build/outputs/apk/debug/app-debug.apk`

## Production note
Real OTP SMS, secure authentication/password reset, employee live-location storage, doctor database and real appointment booking এখনও backend-এ সংযুক্ত করা হয়নি। এগুলোর জন্য Firebase Authentication + Firestore/Realtime Database বা secure API backend লাগবে।
