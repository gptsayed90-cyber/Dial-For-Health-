# Dial for Health — Android starter project

## Included
- Bangla mobile home screen
- Doctor-specialty placeholders
- Appointment request form
- WhatsApp request to 01673616767
- Tap-to-call button
- GitHub Actions workflow to build a debug APK

## Important
This is a starter/demo version. Doctor names, degrees, chambers and availability must be verified before public use. Appointment requests are not automatically confirmed. This app has no backend/database and does not store requests itself.

## Build APK using GitHub Actions
1. Create a GitHub repository and upload the contents of this folder (not the ZIP itself).
2. Open the repository's Actions tab.
3. Select "Build Dial for Health APK" and tap "Run workflow", or push to main.
4. Open the completed workflow run and download artifact `Dial-for-Health-debug-apk`.
5. Extract the artifact ZIP to get `app-debug.apk`, then install it on Android.

Package ID: `com.dialforhealth.app`
