# Dial For Health (নোয়াখালী) v2

Added UI flows:
- Login with phone number + OTP
- Registration
- Forgot Password / account recovery
- Employee Location screen
- Location permission request UI
- Existing medical home page

Important: OTP verification, password reset, employee GPS tracking, and secure user accounts require a real backend such as Firebase Authentication + Firestore/Realtime Database. The included UI is a working prototype and does not send real OTPs yet.
